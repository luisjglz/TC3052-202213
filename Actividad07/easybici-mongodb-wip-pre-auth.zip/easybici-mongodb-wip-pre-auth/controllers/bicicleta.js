const Bicicleta = require('../models/bicicleta')

exports.bicicleta_list = function(req, res){
    //res.render('bicicletas/index', {bicis: Bicicleta.allBicis}) 

    Bicicleta.find({}, function(err, bicis){
        res.render('bicicletas/index', {bicis: bicis}) 
    })
}

exports.bicicleta_create_get = function(req, res){
    res.render('bicicletas/create')
}

exports.bicicleta_create_post = function(req, res){
    let temp_bici = new Bicicleta(req.body.id, req.body.color, req.body.modelo)
    temp_bici.ubicacion = [req.body.lat, req.body.lon]
    Bicicleta.add(temp_bici)
    res.redirect('/bicicletas')
} 

exports.bicicleta_delete_post = function(req, res){
    Bicicleta.removeById(req.params.id) 
    res.redirect('/bicicletas')
}

exports.bicicleta_update_get = function(req, res){
    //let bici = Bicicleta.findById(req.params.id)
    //res.render('bicicletas/update', {bici})

    Bicicleta.findById(req.params.id, function(err, bici){
        res.render('bicicletas/update', {bici})
    })
}

exports.bicicleta_update_post = function(req, res){

    // Bicicleta.findByIdAndUpdate(req.body.id, function(err, bici){

    //     bici.code = req.body.code
    //     bici.color = req.body.color
    //     bici.modelo = req.body.modelo
    //     bici.ubicacion = [req.body.lat, req.body.lon]  

    //     res.redirect('/bicicletas')
    // })

    // Bicicleta.findOneAndUpdate({_id:req.body.id}, req.newData, function(err, doc) {
    //     if (err) return res.send(500, {error: err});
    //     return res.redirect('/bicicletas')
    // });

    Bicicleta.findByIdAndUpdate(req.body.id, 
        { 
            code: req.body.code,
            modelo: req.body.modelo,
            color: req.body.color,
            ubicacion: [req.body.lat, req.body.lon]
        }, function (err, docs) {
        if (err){
            console.log(err)
        }
        else{
            res.redirect('/bicicletas')
        }
    });

}