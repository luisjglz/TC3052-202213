let express = require('express')
let router = express.Router()
let usuariosController = require('../../controllers/api/usuarioControllerAPI')
const usuario = require('../../models/usuario')

//Listar los usuarios
router.get('/', usuariosController.usuarios_list)

//Crear nuevo usuario
router.post('/create', usuariosController.usuarios_create)

//Reservar una bici
router.post('/reservar', usuariosController.usuario_reservar)

module.exports = router;

