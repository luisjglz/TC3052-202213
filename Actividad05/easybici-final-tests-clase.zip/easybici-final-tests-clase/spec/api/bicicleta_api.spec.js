const Bicicleta = require('../../models/bicicleta')
const request = require('request')

describe('Bicicletas API', ()=>{
    describe('GET BICICLETAS', ()=>{
        it('Status 200', ()=>{
            expect(Bicicleta.allBicis.length).toBe(0)
            request.get('http://localhost:3000/api/bicicletas', (error, response, body)=>{
                expect(response.statusCode).toBe(200)
            })
        })
    })
})
