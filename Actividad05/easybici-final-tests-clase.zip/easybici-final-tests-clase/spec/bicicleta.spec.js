const Bicicleta = require('../models/bicicleta')

beforeEach( ()=>{
    Bicicleta.allBicis = []
})

describe('Listado de all bicis', ()=>{
    it('list all the bikes', ()=>{
        expect(Bicicleta.allBicis.length).toBe(0)
    })
})

describe('Bicicleta.add', ()=>{
    it('add a new bike', ()=>{
        expect(Bicicleta.allBicis.length).toBe(0)
        //add a bike
        let b1 = new Bicicleta(1, 'rojo', 'bmx', [19.284770943610578, -99.13729060406136])
        Bicicleta.add(b1)
        expect(Bicicleta.allBicis.length).toBe(1)
        expect(Bicicleta.allBicis[0]).toBe(b1)
    })
})

describe('Bicicleta.findById', ()=>{
    it('find the requested bike', ()=>{
        expect(Bicicleta.allBicis.length).toBe(0)
        //add a bike
        let b1 = new Bicicleta(1, 'rojo', 'bmx', [19.284770943610578, -99.13729060406136])
        let b2 = new Bicicleta(2, 'blanca', 'Benotto', [19.286055116801744, -99.1369912899661])
        Bicicleta.add(b1)
        Bicicleta.add(b2)
        //checar que el find by id sí funciona:
        let tempBici = Bicicleta.findById(1)
        expect(tempBici.id).toBe(1)
        expect(tempBici.color).toBe(b1.color)
        expect(tempBici.modelo).toBe(b1.modelo)
    })
})